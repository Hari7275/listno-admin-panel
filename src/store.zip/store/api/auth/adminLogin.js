

import { getAdminToken } from "../tokenHelper";

console.log("getAdminToken......", getAdminToken());

import {apiSlice} from "../api";

export const adminUserSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    createAdminLogin: builder.mutation({
      query: (body) => ({
        url: `/experience/session/auth/login`,
        method: "POST",
        body,
        headers: {
          "Content-Type": "application/json",
          "X-Device-Id": "sakshi-admin-device-111",
          "X-Device-Type": "ANDROID",
          "X-App-Version": "1.0.0",
          "X-App-Integrity": "<REAL_TOKEN>",
          "X-Language": "en",
          "X-Timezone": "Asia/Kolkata",
          "X-ISD-Code": "IN",
        },
      }),
    }),
  }),
});

export const { useCreateAdminLoginMutation } = adminUserSlice;
