// import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

// const customBaseQuery = async (args, api, extraOptions) => {
//   const state = api.getState();

//   const prod = state.auth?.prod;

//   const baseUrl = "https://listeno-gateway-platform-staging.up.railway.app";

//   const rawBaseQuery = fetchBaseQuery({ baseUrl });
//   return rawBaseQuery(args, api, extraOptions);
// };

// const apiSlice = createApi({
//   reducerPath: "api",
//   baseQuery: customBaseQuery,
//   endpoints: (builder) => ({}),
// });

// export default apiSlice;


import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const baseQuery = fetchBaseQuery({
  baseUrl: "https://listeno-gateway-platform-staging.up.railway.app",
  prepareHeaders: (headers, { getState }) => {
    const token = getState().auth.token; // ✅ correct way

    if (token) {
      headers.set("Authorization", `Bearer ${token}`);
    }

    headers.set("X-Device-Id", "sakshi-admin-device-111");
    headers.set("X-Device-Type", "ANDROID");
    headers.set("X-App-Version", "1.0.0");
    headers.set("X-App-Integrity", "<REAL_TOKEN>");
    headers.set("X-Language", "en");
    headers.set("X-Timezone", "Asia/Kolkata");
    headers.set("X-ISD-Code", "IN");

    return headers;
  },
});

export const apiSlice = createApi({
  reducerPath: "api",
  baseQuery,
  endpoints: () => ({}),
});